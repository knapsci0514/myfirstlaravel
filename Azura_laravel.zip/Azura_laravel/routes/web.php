<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get("/about", ["as" => "about", function() {
  return View::make("about");
}]);

Route::get("/mysubjects", ["as" => "mysubjects", function() {
  return View::make("mysubjects");
}]);

Route::get("/mysocialmedia", ["as" => "mysocialmedia", function() {
  return View::make("mysocialmedia");
}]);

Route::get("/educationalbg", ["as" => "educationalbg", function() {
  return View::make("educationalbg");
}]);

Route::get("/aboutphp2", ["as" => "aboutphp2", function() {
  return View::make("aboutphp2");
}]);

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
